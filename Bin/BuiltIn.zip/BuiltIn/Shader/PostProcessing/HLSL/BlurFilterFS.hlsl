Texture2D uSourceTex : register(t0);
SamplerState uSourceTexSampler : register(s0);

struct PS_INPUT
{
	float4 pos : SV_POSITION;
	float4 color : COLOR0;
	float2 tex0 : TEXCOORD0;
};

cbuffer cbPerFrame
{
	float2 uTexelSize;
};

float4 main(PS_INPUT input) : SV_TARGET
{
	float4 sum = float4(0.0, 0.0, 0.0, 0.0);
	
	float weights[3] = {0.25, 0.5, 0.25};
	sum += uSourceTex.SampleLevel(uSourceTexSampler, input.tex0 + float2(-1.0 * uTexelSize.x, 0.0), 0) * weights[0];
	sum += uSourceTex.SampleLevel(uSourceTexSampler, input.tex0, 0) * weights[1];
	sum += uSourceTex.SampleLevel(uSourceTexSampler, input.tex0 + float2(1.0 * uTexelSize.x, 0.0), 0) * weights[2];
	
	/*
	float weights[9] = {0.05, 0.09, 0.12, 0.15, 0.16, 0.15, 0.12, 0.09, 0.05};
	
	sum += uSourceTex.SampleLevel(uSourceTexSampler, input.tex0 + float2(-4.0 * uTexelSize.x, 0.0), 0.0) * weights[0];
	sum += uSourceTex.SampleLevel(uSourceTexSampler, input.tex0 + float2(-3.0 * uTexelSize.x, 0.0), 0.0) * weights[1];
	sum += uSourceTex.SampleLevel(uSourceTexSampler, input.tex0 + float2(-2.0 * uTexelSize.x, 0.0), 0.0) * weights[2];
	sum += uSourceTex.SampleLevel(uSourceTexSampler, input.tex0 + float2(-1.0 * uTexelSize.x, 0.0), 0.0) * weights[3];
	sum += uSourceTex.SampleLevel(uSourceTexSampler, input.tex0, 0.0) * weights[4];
	sum += uSourceTex.SampleLevel(uSourceTexSampler, input.tex0 + float2(1.0 * uTexelSize.x, 0.0), 0.0) * weights[5];
	sum += uSourceTex.SampleLevel(uSourceTexSampler, input.tex0 + float2(2.0 * uTexelSize.x, 0.0), 0.0) * weights[6];
	sum += uSourceTex.SampleLevel(uSourceTexSampler, input.tex0 + float2(3.0 * uTexelSize.x, 0.0), 0.0) * weights[7];
	sum += uSourceTex.SampleLevel(uSourceTexSampler, input.tex0 + float2(4.0 * uTexelSize.x, 0.0), 0.0) * weights[8];
	*/
	
	return sum;
}