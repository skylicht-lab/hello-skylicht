Texture2D uSourceTex : register(t0);
SamplerState uSourceTexSampler : register(s0);

Texture2D uSourceEmission : register(t1);
SamplerState uSourceEmissionSampler : register(s1);

struct PS_INPUT
{
	float4 pos : SV_POSITION;
	float4 color : COLOR0;
	float2 tex0 : TEXCOORD0;
};

cbuffer cbPerFrame
{
	float4 uCurve;
};

float4 main(PS_INPUT input) : SV_TARGET
{
	float4 src = uSourceTex.SampleLevel(uSourceTexSampler, input.tex0, 0.0);
	float3 m = src.rgb;
	m = min(m, float3(4.0, 4.0, 4.0));
	
	float3 e = uSourceEmission.SampleLevel(uSourceEmissionSampler, input.tex0, 0.0).rgb;
	
	// brightness
	float br = max(max(m.r, m.g), m.b);

	// Under-threshold part: quadratic curve
	float rq = clamp(br - uCurve.x, 0.0, uCurve.y);
	rq = uCurve.z * rq * rq;

	// Combine and apply the brightness response curve.
	m *= max(rq, br - uCurve.w) / max(br, 1e-5);

	return float4(m + e, src.a);
}